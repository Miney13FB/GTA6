# GTA6 LIFE

Guía móvil de GTA 6 con cinco pestañas: **Noticias, Guía** (historia, secundarias y actividades), **Mapa, Trofeos y Trucos**.
Es una sola página (`index.html`), sin servidor ni dependencias. Tu progreso (misiones, trofeos, zonas exploradas, marcadores) se guarda en el propio dispositivo.

## Qué hay en la carpeta

| Archivo | Para qué sirve |
| --- | --- |
| `index.html` | La app entera. |
| `package.json`, `capacitor.config.json` | Configuración para convertir la web en APK con Capacitor. |
| `build-apk.yml` | Receta de GitHub Actions que compila el APK en la nube. Tiene que acabar en `.github/workflows/`. |
| `.gitignore` | Opcional. |

## Subirlo a GitHub desde el móvil

GitHub **no descomprime** los `.zip`: descomprímelo antes en el móvil. En el navegador activa «Sitio de escritorio».

1. En github.com: **+ → New repository**, ponle un nombre (por ejemplo `gta6-life`) y pulsa **Create repository**.
2. Pulsa **uploading an existing file**, elige a la vez `index.html`, `package.json`, `capacitor.config.json`, `README.md` y `build-apk.yml`, y pulsa **Commit changes**.
3. Abre `build-apk.yml` en GitHub, pulsa el lápiz (**Edit**) y, en el cuadro del nombre, escribe delante `.github/workflows/` para que quede `.github/workflows/build-apk.yml`. Pulsa **Commit changes**. Eso arranca solo la compilación.

## Conseguir el APK

1. Pestaña **Actions** → **Compilar APK**. Tarda unos 5-10 minutos. Si no arranca sola, pulsa **Run workflow**.
2. Cuando salga el ✓ verde, abre **Releases** (en la página principal del repositorio) → **GTA6 LIFE - APK** y descarga `GTA6-LIFE.apk`.
3. Ábrelo en el móvil. Android te pedirá permitir instalar apps desde tu navegador. Si Play Protect avisa, elige **Instalar de todos modos**: es un APK de prueba firmado con clave de depuración.

Si sale una ✗ roja, abre esa ejecución, copia el mensaje del paso que falló y pásaselo a Claude para ajustarlo.

## Usarla sin APK, como página web

**Settings → Pages → Build and deployment → Deploy from a branch**, elige `main` y `/ (root)` y pulsa **Save**. En un par de minutos estará en `https://TU-USUARIO.github.io/NOMBRE-DEL-REPO/`. Desde Chrome puedes añadirla a la pantalla de inicio como acceso directo.

## Con ordenador

```bash
mkdir -p .github/workflows && mv build-apk.yml .github/workflows/
git add . && git commit -m "GTA6 LIFE" && git push
```

## Notas

- Los datos y textos se recopilaron de fuentes públicas (la lista está en Ajustes, dentro de la app) y pueden cambiar.
- El mapa de la app es un esquema propio sin escala. El mapa real e interactivo es el de [GTABase](https://www.gtabase.com/es/gta-6/mapa/), que se abre en su web.
- Proyecto de fans, sin relación con Rockstar Games ni Take-Two Interactive.

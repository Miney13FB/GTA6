package com.gtavi.countdown

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.os.Bundle
import android.widget.TextView
import android.widget.LinearLayout
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.os.Handler
import android.os.Looper
import java.time.Duration
import java.time.ZonedDateTime
import java.util.Locale

class MainActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var counter: TextView
    private val tick = object : Runnable {
        override fun run() {
            val target = ZonedDateTime.of(2026, 11, 19, 0, 0, 0, 0, java.time.ZoneId.systemDefault())
            val seconds = Duration.between(ZonedDateTime.now(), target).seconds.coerceAtLeast(0)
            val d = seconds / 86400; val h = (seconds % 86400) / 3600; val m = (seconds % 3600) / 60; val s = seconds % 60
            counter.text = if (seconds == 0L) "¡GTA VI YA ESTÁ AQUÍ!" else String.format(Locale.getDefault(), "%d DÍAS\n%02d:%02d:%02d", d, h, m, s)
            val mgr = AppWidgetManager.getInstance(this@MainActivity)
            mgr.getAppWidgetIds(ComponentName(this@MainActivity, CountdownWidget::class.java)).forEach { CountdownWidget.update(this@MainActivity, mgr, it) }
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(24, 24, 24, 24); setBackgroundColor(Color.rgb(12, 12, 18)) }
        val title = TextView(this).apply { text = "GRAND THEFT AUTO\nVI"; textSize = 34f; setTextColor(Color.rgb(243, 107, 170)); gravity = Gravity.CENTER; setTypeface(null, 1) }
        counter = TextView(this).apply { textSize = 30f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(0, 36, 0, 24); typeface = android.graphics.Typeface.MONOSPACE }
        val hint = TextView(this).apply { text = "19 NOVIEMBRE 2026 · 00:00\n\nAñade el widget GTA VI Countdown desde el menú de widgets de tu pantalla de inicio."; textSize = 14f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER }
        root.addView(title, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        root.addView(counter, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        root.addView(hint, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        setContentView(root)
    }
    override fun onResume() { super.onResume(); handler.post(tick) }
    override fun onPause() { super.onPause(); handler.removeCallbacks(tick) }
}

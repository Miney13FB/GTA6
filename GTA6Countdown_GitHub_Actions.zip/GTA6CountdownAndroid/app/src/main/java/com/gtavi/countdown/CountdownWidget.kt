package com.gtavi.countdown

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.widget.RemoteViews
import android.os.SystemClock
import java.time.Duration
import java.time.ZonedDateTime

class CountdownWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { update(context, manager, it) }
    }

    override fun onReceive(context: Context, intent: android.content.Intent) {
        super.onReceive(context, intent)
        if (intent.action == IntentActions.TIME_TICK || intent.action == IntentActions.TIME_SET || intent.action == IntentActions.TIMEZONE_CHANGED) {
            val manager = AppWidgetManager.getInstance(context)
            manager.getAppWidgetIds(android.content.ComponentName(context, CountdownWidget::class.java)).forEach { update(context, manager, it) }
        }
    }

    companion object {
        private val target = ZonedDateTime.of(2026, 11, 19, 0, 0, 0, 0, java.time.ZoneId.systemDefault())
        fun update(context: Context, manager: AppWidgetManager, id: Int) {
            val now = ZonedDateTime.now()
            val seconds = Duration.between(now, target).seconds.coerceAtLeast(0)
            val days = seconds / 86400
            val remainder = seconds % 86400
            val views = RemoteViews(context.packageName, R.layout.widget_countdown)
            views.setTextViewText(R.id.widget_days, if (seconds == 0L) "¡YA ESTÁ AQUÍ!" else "$days DÍAS")
            views.setChronometer(R.id.widget_clock, SystemClock.elapsedRealtime() + remainder * 1000L, "%s", seconds > 0)
            views.setChronometerCountDown(R.id.widget_clock, true)
            views.setTextViewText(R.id.widget_date, "19 NOV 2026 · 00:00")
            manager.updateAppWidget(id, views)
        }
    }
}

private object IntentActions {
    const val TIME_TICK = "android.intent.action.TIME_TICK"
    const val TIME_SET = "android.intent.action.TIME_SET"
    const val TIMEZONE_CHANGED = "android.intent.action.TIMEZONE_CHANGED"
}

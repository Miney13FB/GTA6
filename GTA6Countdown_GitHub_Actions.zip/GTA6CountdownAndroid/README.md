# GTA VI Countdown — Android widget

Proyecto Android nativo en Kotlin con pantalla principal y widget de pantalla de inicio.

- Objetivo: 19/11/2026 a las 00:00, zona horaria local del dispositivo.
- El widget muestra días y un cronómetro HH:MM:SS que actualiza los segundos mediante el componente Chronometer de Android, sin alarmas por segundo.
- Android limita la frecuencia de actualización periódica de widgets; los segundos se muestran con Chronometer nativo y no dependen de refrescar el widget cada segundo. Los días se recalculan en las actualizaciones del sistema. La pantalla de la app sí actualiza cada segundo.

## Compilar
Abrir la carpeta en Android Studio con JDK 17 y Android SDK 35. Ejecutar `assembleDebug` para generar el APK.
